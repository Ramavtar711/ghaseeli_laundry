                   
        <footer class="footer">
    <div class="container-fluid">

        <div class="copyright">
            &copy; 2022 
            <span class="text-dark">Admin</span>
            
        </div>
    </div>
</footer>    </div>

    <script src="<?php echo base_url(); ?>ar_assets/admin/js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>ar_assets/admin/js/Chart.extension.js"></script>
    <script src="<?php echo base_url(); ?>ar_assets/admin/js/map.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDOz5oWyuWCeyh-9c1W5gexDzRakcRP-eM" async defer></script>
    
    
   <!-- <script src="<?php echo base_url(); ?>ar_assets/admin/js/sweetalert.all.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
    
    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.21/b-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/datatables.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.min.js" integrity="sha512-efUTj3HdSPwWJ9gjfGR71X9cvsrthIA78/Fvd/IN+fttQVy7XWkOAXb295j8B3cmm/kFKVxjiNYzKw9IQJHIuQ==" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.js"></script>
    

    
    <script src="<?php echo base_url(); ?>ar_assets/admin/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>ar_assets/admin/js/bootstrap-wysihtml5.js"></script>

    <script src="<?php echo base_url(); ?>ar_assets/admin/js/argon.js"></script>
    <script src="<?php echo base_url(); ?>ar_assets/admin/js/myjavascript.js"></script>
    
    </body>
</html>